io.write("Welcome to Kotel Installer:")
io.write("\n *this installer is a demo,it does nothing*")